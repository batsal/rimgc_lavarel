'use strict';

module.exports = require('./syntax');
