var createGenerator = require('./create');
var config = require('../syntax/config/parser');

module.exports = createGenerator(config);
