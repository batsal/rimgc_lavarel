module.exports = require('./common/selectorList');
