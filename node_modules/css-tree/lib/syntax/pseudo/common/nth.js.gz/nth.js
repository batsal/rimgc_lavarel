var List = require('../../../utils/list');
var DISALLOW_OF_CLAUSE = false;

module.exports = {
    parse: function nth() {
        return new List().appendData(
            this.Nth(DISALLOW_OF_CLAUSE)
        );
    }
};
