'use stirct';

module.exports = require('./async').filter;
