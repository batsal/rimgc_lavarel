export = isPlainObject;

declare function isPlainObject(o: any): boolean;

declare namespace isPlainObject {}
