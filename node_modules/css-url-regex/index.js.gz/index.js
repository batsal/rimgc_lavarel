'use strict'

module.exports = function () {
  return /url\((.*?)\)/ig
}
