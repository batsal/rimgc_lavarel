'use strict';

var Set = require('../');

module.exports = function () { return new Set(this); };
