var convert = require('./convert'),
    func = convert('rangeRight', require('../rangeRight'));

func.placeholder = require('./placeholder');
module.exports = func;
