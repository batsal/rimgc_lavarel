var convert = require('./convert'),
    func = convert('zipWith', require('../zipWith'));

func.placeholder = require('./placeholder');
module.exports = func;
