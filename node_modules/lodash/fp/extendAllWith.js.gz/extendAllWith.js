module.exports = require('./assignInAllWith');
