var convert = require('./convert'),
    func = convert('templateSettings', require('../templateSettings'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
