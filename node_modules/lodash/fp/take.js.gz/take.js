var convert = require('./convert'),
    func = convert('take', require('../take'));

func.placeholder = require('./placeholder');
module.exports = func;
