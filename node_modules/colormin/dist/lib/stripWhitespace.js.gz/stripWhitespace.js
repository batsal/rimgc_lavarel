'use strict';

exports.__esModule = true;

exports.default = function (str) {
  return str.replace(/\s/g, '');
};

module.exports = exports['default'];