# 1.x releases

The contents of this section have been generated automatically; each version
tracks the `caniuse-db` package at the same version.

-   **1.0.30000821** was released on March 28th, 2018 at 04:00.
-   **1.0.30000820** was released on March 25th, 2018 at 05:01.
-   **1.0.30000819** was released on March 22nd, 2018 at 06:01.
-   **1.0.30000817** was released on March 21st, 2018 at 06:01.
-   **1.0.30000815** was released on March 15th, 2018 at 06:01.
-   **1.0.30000814** was released on March 13th, 2018 at 06:01.
-   **1.0.30000813** was released on March 6th, 2018 at 07:00.
-   **1.0.30000812** was released on March 5th, 2018 at 05:01.
-   **1.0.30000811** was released on March 3rd, 2018 at 08:01.
-   **1.0.30000810** was released on February 20th, 2018 at 00:00.
-   **1.0.30000809** was released on February 18th, 2018 at 02:01.
-   **1.0.30000808** was released on February 11th, 2018 at 07:00.
-   **1.0.30000807** was released on February 10th, 2018 at 06:00.
-   **1.0.30000805** was released on February 9th, 2018 at 05:00.
-   **1.0.30000804** was released on February 7th, 2018 at 07:00.
-   **1.0.30000803** was released on February 6th, 2018 at 07:00.
-   **1.0.30000802** was released on February 5th, 2018 at 23:14.
-   **1.0.30000792** was released on January 15th, 2018 at 06:01.
-   **1.0.30000791** was released on January 12th, 2018 at 06:01.
-   **1.0.30000790** was released on January 11th, 2018 at 08:00.
-   **1.0.30000789** was released on January 7th, 2018 at 05:00.
-   **1.0.30000788** was released on January 7th, 2018 at 04:00.
-   **1.0.30000787** was released on January 3rd, 2018 at 23:00.
-   **1.0.30000786** was released on January 3rd, 2018 at 19:00.
-   **1.0.30000785** was released on January 3rd, 2018 at 18:01.
-   **1.0.30000784** was released on December 20th, 2017 at 05:01.
-   **1.0.30000783** was released on December 13th, 2017 at 06:01.
-   **1.0.30000782** was released on December 10th, 2017 at 07:01.
-   **1.0.30000781** was released on December 10th, 2017 at 06:01.
-   **1.0.30000780** was released on December 6th, 2017 at 06:01.
-   **1.0.30000779** was released on December 6th, 2017 at 05:01.
-   **1.0.30000778** was released on December 4th, 2017 at 07:01.
-   **1.0.30000777** was released on December 1st, 2017 at 07:00.
-   **1.0.30000776** was released on December 1st, 2017 at 05:01.
-   **1.0.30000775** was released on November 29th, 2017 at 06:00.
-   **1.0.30000774** was released on November 29th, 2017 at 05:01.
-   **1.0.30000772** was released on November 26th, 2017 at 07:01.
-   **1.0.30000770** was released on November 23rd, 2017 at 06:01.
-   **1.0.30000769** was released on November 21st, 2017 at 06:01.
-   **1.0.30000766** was released on November 17th, 2017 at 06:01.
-   **1.0.30000765** was released on November 16th, 2017 at 05:00.
-   **1.0.30000764** was released on November 14th, 2017 at 07:00.
-   **1.0.30000762** was released on November 14th, 2017 at 06:00.
-   **1.0.30000760** was released on November 8th, 2017 at 04:00.
-   **1.0.30000758** was released on November 3rd, 2017 at 06:01.
-   **1.0.30000757** was released on November 2nd, 2017 at 06:00.
-   **1.0.30000756** was released on October 30th, 2017 at 06:00.
-   **1.0.30000755** was released on October 28th, 2017 at 07:00.
-   **1.0.30000753** was released on October 28th, 2017 at 06:00.
-   **1.0.30000752** was released on October 27th, 2017 at 05:00.
-   **1.0.30000751** was released on October 26th, 2017 at 05:00.
-   **1.0.30000750** was released on October 25th, 2017 at 05:00.
-   **1.0.30000749** was released on October 22nd, 2017 at 23:00.
-   **1.0.30000748** was released on October 19th, 2017 at 06:00.
-   **1.0.30000747** was released on October 18th, 2017 at 06:00.
-   **1.0.30000746** was released on October 11th, 2017 at 05:00.
-   **1.0.30000745** was released on October 9th, 2017 at 03:00.
-   **1.0.30000744** was released on October 5th, 2017 at 06:01.
-   **1.0.30000743** was released on October 4th, 2017 at 06:00.
-   **1.0.30000742** was released on October 4th, 2017 at 05:01.
-   **1.0.30000741** was released on October 3rd, 2017 at 04:00.
-   **1.0.30000740** was released on September 29th, 2017 at 05:00.
-   **1.0.30000739** was released on September 28th, 2017 at 05:00.
-   **1.0.30000738** was released on September 25th, 2017 at 07:00.
-   **1.0.30000737** was released on September 24th, 2017 at 06:00.
-   **1.0.30000736** was released on September 24th, 2017 at 05:00.
-   **1.0.30000735** was released on September 22nd, 2017 at 05:00.
-   **1.0.30000734** was released on September 22nd, 2017 at 01:00.
-   **1.0.30000733** was released on September 18th, 2017 at 05:00.
-   **1.0.30000732** was released on September 17th, 2017 at 06:00.
-   **1.0.30000731** was released on September 16th, 2017 at 06:00.
-   **1.0.30000730** was released on September 15th, 2017 at 06:00.
-   **1.0.30000727** was released on September 11th, 2017 at 07:00.
-   **1.0.30000726** was released on September 6th, 2017 at 04:00.
-   **1.0.30000725** was released on September 5th, 2017 at 06:00.
-   **1.0.30000724** was released on September 5th, 2017 at 05:00.
-   **1.0.30000723** was released on September 4th, 2017 at 20:00.
-   **1.0.30000722** was released on September 4th, 2017 at 05:00.
-   **1.0.30000721** was released on August 30th, 2017 at 06:00.
-   **1.0.30000720** was released on August 30th, 2017 at 05:00.
-   **1.0.30000718** was released on August 25th, 2017 at 07:00.
-   **1.0.30000717** was released on August 22nd, 2017 at 04:00.
-   **1.0.30000716** was released on August 20th, 2017 at 07:00.
-   **1.0.30000715** was released on August 11th, 2017 at 06:00.
-   **1.0.30000714** was released on August 11th, 2017 at 05:00.
-   **1.0.30000713** was released on August 9th, 2017 at 06:00.
-   **1.0.30000712** was released on August 7th, 2017 at 04:00.
-   **1.0.30000711** was released on August 7th, 2017 at 01:00.
-   **1.0.30000710** was released on August 4th, 2017 at 03:00.
-   **1.0.30000709** was released on August 1st, 2017 at 05:00.
-   **1.0.30000708** was released on July 27th, 2017 at 07:01.
-   **1.0.30000706** was released on July 25th, 2017 at 16:06.
-   **1.0.30000704** was released on July 20th, 2017 at 07:01.
-   **1.0.30000703** was released on July 19th, 2017 at 06:01.
-   **1.0.30000702** was released on July 18th, 2017 at 08:01.
-   **1.0.30000701** was released on July 14th, 2017 at 06:01.
-   **1.0.30000700** was released on July 12th, 2017 at 07:01.
-   **1.0.30000699** was released on July 11th, 2017 at 06:02.
-   **1.0.30000698** was released on July 10th, 2017 at 06:01.
-   **1.0.30000697** was released on July 5th, 2017 at 06:01.
-   **1.0.30000696** was released on June 27th, 2017 at 07:01.
-   **1.0.30000695** was released on June 27th, 2017 at 05:01.
-   **1.0.30000694** was released on June 24th, 2017 at 05:01.
-   **1.0.30000693** was released on June 22nd, 2017 at 04:01.
-   **1.0.30000692** was released on June 19th, 2017 at 07:01.
-   **1.0.30000690** was released on June 18th, 2017 at 07:01.
-   **1.0.30000689** was released on June 18th, 2017 at 06:01.
-   **1.0.30000688** was released on June 18th, 2017 at 05:01.
-   **1.0.30000687** was released on June 18th, 2017 at 04:01.
-   **1.0.30000686** was released on June 15th, 2017 at 07:01.
-   **1.0.30000684** was released on June 13th, 2017 at 05:01.
-   **1.0.30000683** was released on June 10th, 2017 at 05:01.
-   **1.0.30000680** was released on June 8th, 2017 at 08:01.
-   **1.0.30000679** was released on June 6th, 2017 at 06:01.
-   **1.0.30000677** was released on June 5th, 2017 at 00:01.
-   **1.0.30000676** was released on May 30th, 2017 at 06:01.
-   **1.0.30000674** was released on May 28th, 2017 at 06:01.
-   **1.0.30000673** was released on May 27th, 2017 at 06:01.
-   **1.0.30000672** was released on May 26th, 2017 at 06:01.
-   **1.0.30000671** was released on May 25th, 2017 at 07:01.
-   **1.0.30000670** was released on May 15th, 2017 at 07:01.
-   **1.0.30000669** was released on May 14th, 2017 at 06:01.
-   **1.0.30000668** was released on May 14th, 2017 at 05:01.
-   **1.0.30000667** was released on May 12th, 2017 at 07:01.
-   **1.0.30000666** was released on May 8th, 2017 at 06:01.
-   **1.0.30000665** was released on May 3rd, 2017 at 08:01.
-   **1.0.30000664** was released on April 28th, 2017 at 06:01.
-   **1.0.30000663** was released on April 28th, 2017 at 05:01.
-   **1.0.30000662** was released on April 26th, 2017 at 07:01.
-   **1.0.30000661** was released on April 26th, 2017 at 06:01.
-   **1.0.30000660** was released on April 24th, 2017 at 17:01.
-   **1.0.30000659** was released on April 24th, 2017 at 00:01.
-   **1.0.30000657** was released on April 21st, 2017 at 06:01.
-   **1.0.30000656** was released on April 20th, 2017 at 12:16.
-   **1.0.30000655** was released on April 17th, 2017 at 17:06.

# 0.3.0

-   Add the `title` key to each feature.
-   Update `caniuse-db` to `1.0.30000653`.
-   Test automated publish script.

# 0.2.0

-   Rewrite of the module. Now tries to be less clever with version merging,
    instead opting for base62 identifiers for versions, and it is now tested
    for accuracy against the original data.
-   `null` versions are now preserved to be consistent with caniuse-db.
-   All data is now stored as JS objects rather than JSON.
-   The browser map is now automatically generated.

# 0.1.0

-   Initial release.
