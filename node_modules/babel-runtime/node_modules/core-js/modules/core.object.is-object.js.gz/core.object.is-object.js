var $export = require('./_export');

$export($export.S + $export.F, 'Object', { isObject: require('./_is-object') });
