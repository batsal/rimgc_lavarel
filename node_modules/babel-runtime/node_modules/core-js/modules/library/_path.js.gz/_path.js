module.exports = require('./_core');
