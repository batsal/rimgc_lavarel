require('../../modules/es6.math.log1p');
module.exports = require('../../modules/_core').Math.log1p;
