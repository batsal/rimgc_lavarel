require('../../modules/es7.math.signbit');

module.exports = require('../../modules/_core').Math.signbit;
