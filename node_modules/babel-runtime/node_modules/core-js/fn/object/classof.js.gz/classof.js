require('../../modules/core.object.classof');
module.exports = require('../../modules/_core').Object.classof;
