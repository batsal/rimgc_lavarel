require('../../modules/es6.number.constructor');
module.exports = Number;
