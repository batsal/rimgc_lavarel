require('../../modules/es6.reflect.has');
module.exports = require('../../modules/_core').Reflect.has;
