require('../../../modules/es6.string.fontsize');
module.exports = require('../../../modules/_entry-virtual')('String').fontsize;
