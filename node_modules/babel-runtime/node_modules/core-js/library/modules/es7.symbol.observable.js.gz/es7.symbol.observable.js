require('./_wks-define')('observable');
