require('../../modules/es6.math.sign');
module.exports = require('../../modules/_core').Math.sign;
