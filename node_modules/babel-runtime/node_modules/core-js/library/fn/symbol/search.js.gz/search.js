require('../../modules/es6.regexp.search');
module.exports = require('../../modules/_wks-ext').f('search');
