"use strict";

module.exports = require("./_iterate")("every", true);
