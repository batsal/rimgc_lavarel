"use strict";

module.exports = function (t, a) {
	a.deep(t([63, 171, 34, 209], 8, 23), 1.3370000123977661);
};
