"use strict";

var isImplemented = require("../../../math/log1p/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
