"use strict";

var isImplemented = require("../../../math/clz32/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
