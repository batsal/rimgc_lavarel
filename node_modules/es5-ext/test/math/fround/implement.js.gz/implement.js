"use strict";

var isImplemented = require("../../../math/fround/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
