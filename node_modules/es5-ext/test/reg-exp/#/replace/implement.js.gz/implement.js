"use strict";

var isImplemented = require("../../../../reg-exp/#/replace/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
