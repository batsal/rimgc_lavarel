"use strict";

module.exports = function (t, a) {
	a(t.call("raz-dwa-t-rzy-4y-rtr4-tiu-45-pa"), "razDwaTRzy4yRtr4Tiu45Pa");
	a(t.call("raz-dwa-t-rzy-4y-rtr4-tiu-45-pa-"), "razDwaTRzy4yRtr4Tiu45Pa-");
	a(t.call("raz-dwa-t-rzy-4y-rtr4-tiu-45-pa--"), "razDwaTRzy4yRtr4Tiu45Pa--");
};
