"use strict";

module.exports = {
	throw: require("./throw")
};
