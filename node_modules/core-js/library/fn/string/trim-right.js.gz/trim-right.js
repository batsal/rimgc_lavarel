require('../../modules/es7.string.trim-right');
module.exports = require('../../modules/$.core').String.trimRight;