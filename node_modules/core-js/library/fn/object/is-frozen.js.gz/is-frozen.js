require('../../modules/es6.object.is-frozen');
module.exports = require('../../modules/$.core').Object.isFrozen;