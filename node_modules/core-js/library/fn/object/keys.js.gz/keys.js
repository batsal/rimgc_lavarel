require('../../modules/es6.object.keys');
module.exports = require('../../modules/$.core').Object.keys;