require('../../modules/es6.symbol');
module.exports = require('../../modules/$.core').Symbol['for'];