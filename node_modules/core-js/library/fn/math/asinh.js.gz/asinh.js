require('../../modules/es6.math.asinh');
module.exports = require('../../modules/$.core').Math.asinh;