require('../../modules/es7.object.get-own-property-descriptors');
module.exports = require('../../modules/$.core').Object.getOwnPropertyDescriptors;