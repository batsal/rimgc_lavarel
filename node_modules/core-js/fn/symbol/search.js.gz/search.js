require('../../modules/es6.regexp.search');
module.exports = require('../../modules/$.wks')('search');