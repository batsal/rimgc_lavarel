require('../../modules/es7.string.pad-right');
module.exports = require('../../modules/$.core').String.padRight;