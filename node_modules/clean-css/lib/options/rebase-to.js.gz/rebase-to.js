var path = require('path');

function rebaseToFrom(option) {
  return option ? path.resolve(option) : process.cwd();
}

module.exports = rebaseToFrom;
