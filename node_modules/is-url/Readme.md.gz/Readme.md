# is-url

Check whether a string is a URL.

## Installation

```sh
npm install is-url
```

## API

### `isUrl(string)`

Returns a Boolean indicating whether `string` is a URL.

## License

MIT
