"use strict";

exports.__esModule = true;
exports.default = remove;
function remove(node) {
    return node.remove();
}
module.exports = exports["default"];