"use strict";

exports.__esModule = true;
exports.default = getValue;
function getValue(_ref) {
    var value = _ref.value;

    return value;
}
module.exports = exports["default"];