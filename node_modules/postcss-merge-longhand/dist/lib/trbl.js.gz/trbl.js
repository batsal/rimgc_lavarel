'use strict';

exports.__esModule = true;
exports.default = ['top', 'right', 'bottom', 'left'];
module.exports = exports['default'];