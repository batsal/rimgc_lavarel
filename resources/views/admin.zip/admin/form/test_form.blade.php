<div class="tabs">
                      <ul class="tab-links">
                          <li class="active"><a href="#tab1"><i class="fa fa-bars"></i>Tests</a></li>
                          <li><a href="#tab2"><i class="fa fa-bars"></i>HPO</a></li>
                      </ul>
                      <div class="tab-content">
                          <div id="tab1" class="tab active">
                            <table class="table table-striped table-responsive" id="test">
                              <thead>
                                <tr>
                                  <th scope="col">Test</th>
                                  <th scope="col" style="width: 10px;">IMGC ordered</th>
                                  <th scope="col" style="width: 10px;">Lab Initiated</th>
                                  <th scope="col">Lab Used</th>
                                  <th scope="col">Date <br/>Recorded</th>
                                  <th scope="col">Patient <br/>Type</th>
                                  <th scope="col">Sample <br/>Status</th>
                                  <th scope="col">Result</th>
                                  <th scope="col">Diagnostic</th>
                                  <th scope="col"></th>
                                   <th scope="col"></th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                    
                                    <td scope="col">
                                      <div class="form-group">
                                               
                                                <div class="col-lg-10">
                                                  <select class="form-control m-bot15" name="test[test_name][]">
                                                                          <option>1</option>
                                                                          <option>2</option>
                                                                          <option>3</option>
                                                                          <option>4</option>
                                                                          <option>5</option>
                                                                      </select>
                                                  
                                                </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                       <div class="checkbox">
                                                <label>
                                                                      <input type="checkbox" name="test[img_ordered][]" value="Yes">
                                                                  </label>
                                              </div>
                                    </td>
                                    <td scope="col">
                                    <div class="form-group">
                                       <div class="checkbox">
                                                <label>
                                                      <input type="checkbox" name="test[lab_initiated][]" value="Yes">
                                                                  </label>
                                              </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                       <div class="form-group">
                                                
                                                <div class="col-lg-10">
                                                  <select class="form-control m-bot15" name="test[lab_used][]">
                                                                          <option value="">1</option>
                                                                          <option value="">2</option>
                                                                          <option value="">3</option>
                                                                          <option value="">4</option>
                                                                          <option value="">5</option>
                                                                      </select>
                                                  
                                                </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                       <div class="form-group">
                                            
                                                    <input type="date" class="form-control" id="date_ordered"  
                                                    name="test[date_ordered][]" style="width: 85%; margin-top: -15px;">
                                                  </div>
                                                
                                    </td>
                                    <td scope="col">
                                      <div class="form-group">
                                               
                                                <div class="col-lg-10">
                                                  <select class="form-control m-bot15" name="test[patient_type][]">
                                                                          <option value="">1</option>
                                                                          <option value="">2</option>
                                                                          <option value="">3</option>
                                                                          <option value="">4</option>
                                                                          <option value="">5</option>
                                                  </select>
                                                  
                                                </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                     <div class="form-group">
                                               
                                                <div class="col-lg-10">
                                                  <select class="form-control m-bot15" name="test[sample_status][]">
                                                                          <option>1</option>
                                                                          <option>2</option>
                                                                          <option>3</option>
                                                                          <option>4</option>
                                                                          <option>5</option>
                                                                      </select>
                                                  
                                                </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                      <div class="radios">
                                                            <label class="label_radio" for="result-01">
                                                                                      <input name="test[result][0]" id="result-01" value="Yes" type="radio" checked /> Yes
                                                                                  </label>
                                                            <label class="label_radio" for="result-02">
                                                                                      <input name="test[result][0]" id="result-02" value="No" type="radio" /> No
                                                                                  </label>


                                                          </div>
                                    </td>
                                    <td scope="col">
                                      <div class="form-group">
                                               
                                                <div class="col-lg-10">
                                                  <select class="form-control m-bot15" name="test[diagnostic][]">
                                                                          <option value="0"a>---Select---</option>
                                                                          <option value="Positive">Positive</option>
                                                                          <option value="Negative">Negative</option>
                                                                          <option value="Uncertain">Uncertain</option>
                                                                          <!-- <option value="">5</option> -->
                                                                      </select>
                                                  
                                                </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                          <div class="form-group">
                                             <div class="checkbox"  style="text-align: left;">
                                                      <label> 
                                                        <input type="checkbox" name="test[lab_initiated][]" value=""> Test Not Performed
                                                      </label>
                                              </div>
                                          </div>

                                    </td>
                                    <td scope="col">
                                    <div class="form-group">
                                        <button type="button" class="btn btn-default btn-sm add">
                                          <span class="fa fa-plus"></span>
                                        </button>
                                        <button type="button" class="btn btn-default btn-sm delete">
                                            <span class="fa fa-times"></span> 
                                        </button>
                                    </div>
                                    </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <div id="tab2" class="tab">
                              <section class="panel">
                                  <header class="panel-heading">
                                    HPO Terms
                                  </header>
                                  <p>Copy and Paste from directly Epic</p>
                                  <div class="panel-body">
                                    <div id="editor" class="btn-toolbar cke_editable cke_editable_inline cke_contents_ltr" data-role="editor-toolbar" data-target="#editor" tabindex="0" spellcheck="false" style="position: relative;" role="textbox" aria-label="Rich Text Editor, editor" title="Rich Text Editor, editor" aria-describedby="cke_48" contenteditable="true" name="hpo"><p><br></p></div>
                                  </div>
                              </section>
                          </div>
                      </div>
</div>


