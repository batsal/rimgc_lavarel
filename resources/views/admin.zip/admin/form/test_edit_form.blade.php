        <div class="tabs">
                      <ul class="tab-links">
                          <li class="active"><a href="#tab1"><i class="fa fa-bars"></i>Tests</a></li>
                          <li><a href="#tab2"><i class="fa fa-bars"></i>HPO</a></li>
                      </ul>
                      <div class="tab-content">
                          <div id="tab1" class="tab active">
                            <table class="table table-responsive table-striped" id="test">
                              <thead>
                                <tr>
                                  <th scope="col">Test</th>
                                  <th scope="col" style="width: 10px;">IMGC ordered</th>
                                  <th scope="col" style="width: 10px;">Lab Initiated</th>
                                  <th scope="col">Lab Used</th>
                                  <th scope="col">Date <br/>Recorded</th>
                                  <th scope="col">Patient <br/>Type</th>
                                  <th scope="col">Sample <br/>Status</th>
                                  <th scope="col">Result</th>
                                  <th scope="col">Diagnostic</th>
                                  <th scope="col"></th>
                                   <th scope="col"></th>
                                </tr>
                              </thead>
                              <tbody>
                               

                                @foreach($edit -> test as $key => $t)

                                <tr>
                                    
                                    <td scope="col">
                                      <div class="form-group">
                                               
                                                <div class="col-lg-10">
                                                  <select class="form-control m-bot15" name="test[test_name][]">
                                                                          <option value="1" 
                                                                          @if("1"==$t->test_name)   selected @endif>1</option>
                                                                          <option value="2" @if("2"==$t->test_name)   selected @endif>2</option>
                                                                          <option value="3" @if("3"==$t->test_name)   selected @endif>3</option>
                                                                          <option value="4" @if("4"==$t->test_name)   selected @endif>4</option>
                                                                          <option value="5" @if("5"==$t->test_name)   selected @endif>5</option>
                                                                      </select>
                                                  
                                                </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                       <div class="checkbox">
                                                <label>
                                                                      <input type="checkbox" name="test[img_ordered][]" value="Yes" @if("Yes"==$t->img_ordered)   checked @endif>
                                                                  </label>
                                              </div>
                                    </td>
                                    <td scope="col">
                                    <div class="form-group">
                                       <div class="checkbox">
                                                <label>
                                                      <input type="checkbox" name="test[lab_initiated][]" value="Yes" @if("Yes"==$t->lab_initiated)   checked @endif>
                                                                  </label>
                                              </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                       <div class="form-group">
                                                
                                                <div class="col-lg-10">
                                                  <select class="form-control m-bot15" name="test[lab_used][]">
                                                                          <option value="1" 
                                                                          @if("5"==$t->lab_used) selected @endif>1</option>
                                                                          <option value="2" 
                                                                          @if("2"==$t->lab_used) selected @endif>2</option>
                                                                          <option value="3" 
                                                                           @if("3"==$t->lab_used)   selected @endif

                                                                          >3</option>
                                                                          <option value="4"
                                                                           @if("4"==$t->lab_used)   selected @endif
                                                                          >4</option>
                                                                          <option value="5" 
                                                                           @if("5"==$t->lab_used)   selected @endif
                                                                          >5</option>
                                                                      </select>
                                                  
                                                </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                       <div class="form-group">
                                            
                                                    <input type="date" class="form-control" id="date_ordered"  
                                                    name="test[date_ordered][]" value="{{$t->date_ordered}}" style="width: 85%;margin-top: -15px;">
                                                  </div>
                                                
                                    </td>
                                    <td scope="col">
                                      <div class="form-group">
                                               
                                                <div class="col-lg-10">
                                                  <select class="form-control m-bot15" name="test[patient_type][]">
                                                                          <option value="1" 
                                                                            @if("1"==$t->patient_type)   selected @endif
                                                                          >1</option>
                                                                          <option value="2"
                                                                           @if("2"==$t->patient_type)   selected @endif
                                                                          >2</option>
                                                                          <option value="3"
                                                                            @if("3"==$t->patient_type)   selected @endif
                                                                          >3</option>
                                                                          <option value="4"
                                                                                    @if("4"==$t->patient_type)   selected @endif
                                                                          >4</option>
                                                                          <option value="5"
                                                                              @if("5"==$t->patient_type)   selected @endif
                                                                          >5</option>
                                                  </select>
                                                  
                                                </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                     <div class="form-group">
                                               
                                                <div class="col-lg-10">
                                                  <select class="form-control m-bot15" name="test[sample_status][]">
                                                                          <option value="1" 
                                                                            @if("1"==$t->sample_status)   selected @endif
                                                                          >1</option>
                                                                          <option value="2"
                                                                           @if("2"==$t->sample_status)   selected @endif
                                                                          >2</option>
                                                                          <option value="3"
                                                                            @if("3"==$t->sample_status)   selected @endif
                                                                          >3</option>
                                                                          <option value="4"
                                                                                    @if("4"==$t->sample_status)   selected @endif
                                                                          >4</option>
                                                                          <option value="5"
                                                                              @if("5"==$t->sample_status)   selected @endif
                                                                          >5</option>
                                                                      </select>
                                                  
                                                </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                      <div class="radios">
                                                            <label class="label_radio" for="result-01">

                                                                                      <input name="test[result][{{$key}}]" id="result-01" value="Yes" type="radio" @if("Yes"==$t->result)   checked @endif /> Yes
                                                                                  </label>
                                                            <label class="label_radio" for="result-02">
                                                                                      <input name="test[result][{{$key}}]" id="result-02" value="No" type="radio"  @if("Yes"==$t->result)   checked @endif /> Yes
                                                                                  </label>



                                                          </div>
                                    </td>
                                    <td scope="col">
                                      <div class="form-group">
                                               
                                                <div class="col-lg-10">
                                                  <select class="form-control m-bot15" name="test[diagnostic][]">
                                                                          <option value="0">---Select---</option>
                                                                          <option value="Positive"
                                                                          @if("Positive"==$t->diagnostic) selected @endif
                                                                          >Positive</option>
                                                                          <option value="Negative"
                                                                             @if("Negative"==$t->diagnostic)   selected @endif
                                                                          >Negative</option>
                                                                          <option value="Uncertain"
                                                                           @if("Uncertain"==$t->diagnostic)   selected @endif
                                                                          >Uncertain</option>
                                                                          <!-- <option value="">5</option> -->
                                                                      </select>
                                                  
                                                </div>
                                              </div>
                                    </td>
                                    <td scope="col">
                                          <div class="form-group">
                                             <div class="checkbox text-left" style="text-align: left;">
                                                      <label> 
                                                        <input type="checkbox" name="test[lab_initiated][]" 
                                                        value="Yes" @if($t -> lab_initiated == "Yes") checked @endif> Test Not Performed
                                                      </label>
                                              </div>
                                          </div>

                                    </td>

                                    <td scope="col">
                                    <div class="form-group">
                                        <button type="button" class="btn btn-default btn-sm add">
                                         <span class="fa fa-plus"></span>
                                        </button>
                                        <button type="button" class="btn btn-default btn-sm delete">
                                           <span class="fa fa-times"></span> 
                                        </button>
                                    </div>
                                    </td>
                                </tr>
                                @endforeach
                              </tbody>
                            </table>
                          </div>
                          <div id="tab2" class="tab">
                              <section class="panel">
                                  <header class="panel-heading">
                                    HPO Terms
                                  </header>
                                  <p>Copy and Paste from directly Epic</p>
                                  <div class="panel-body">
                                    <div id="editor" class="btn-toolbar cke_editable cke_editable_inline cke_contents_ltr" data-role="editor-toolbar" data-target="#editor" tabindex="0" spellcheck="false" style="position: relative;" role="textbox" aria-label="Rich Text Editor, editor" title="Rich Text Editor, editor" aria-describedby="cke_48" contenteditable="true" name="hpo"><p><br></p></div>
                                  </div>
                              </section>
                          </div>
                      </div>
</div>


